USE [compliancetest]
GO

/****** Object:  Table [dbo].[home_Updatedrecord]    Script Date: 3/2/2021 3:35:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[home_Updatedrecord](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[sdate] [varchar](max) NULL,
	[fileupno] [varchar](max) NULL,
	[branchname] [varchar](max) NULL,
	[cname] [varchar](max) NULL,
	[acno] [varchar](max) NULL,
	[benname] [varchar](max) NULL,
	[amount] [varchar](max) NULL,
	[currency] [varchar](max) NULL,
	[country] [varchar](max) NULL,
	[accdrec] [varchar](max) NULL,
	[shdocrec] [varchar](max) NULL,
	[pletterr] [varchar](max) NULL,
	[scontactr] [varchar](max) NULL,
	[largr] [varchar](max) NULL,
	[duedate] [varchar](max) NULL,
	[extduedate] [varchar](max) NULL,
	[goods] [varchar](max) NULL,
	[invoice] [varchar](max) NULL,
	[extenddatedate] [varchar](max) NULL,
	[extreason] [varchar](max) NULL,
	[complete] [varchar](max) NULL,
	[cfileupno] [varchar](max) NULL,
	[incomplete] [varchar](max) NULL,
	[incocomment] [varchar](max) NULL,
	[employees_name] [varchar](max) NULL,
	[deleted_at] [varchar](max) NULL,
 CONSTRAINT [PK_Sp-home_Updatedrecord] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


