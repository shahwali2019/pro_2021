USE [compliancetest]
GO

/****** Object:  StoredProcedure [dbo].[sp_Homeupdated_Record]    Script Date: 3/2/2021 3:38:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create procedure  [dbo].[sp_Homeupdated_Record]
(
@id int,  
@sdate         varchar(max),  
@fileupno      varchar(max),
@branchname	   varchar(max),
@cname 		   varchar(max),
@acno 		   varchar(max),
@benname 	   varchar(max),
@currency 	   varchar(max),
@country 	   varchar(max),
@accdrec 	   varchar(max),
@shdocrec 	   varchar(max),
@pletterr 	   varchar(max),
@scontactr	   varchar(max),
@largr 		   varchar(max),
@duedate 	   varchar(max),
@extduedate    varchar(max),
@goods 		   varchar(max),
@invoice 	   varchar(max),
@extenddatedate varchar(max),
@extreason 	   varchar(max),
@complete 	   varchar(max),
@cfileupno 	   varchar(max),
@incomplete    varchar(max),
@incocomment    varchar(max),
@employees_name varchar(max),
@deleted_at    varchar(max)
)

as 

insert into home_Updatedrecord 
select id,sdate,fileupno,branchname,cname,acno,benname,currency,country,accdrec,shdocrec,pletterr,scontactr,largr,duedate,extduedate,goods,invoice,extenddatedate,extreason,complete,cfileupno,incomplete,incocomment,employees_name,getdate() from HomesTest where id=@id

UPDATE HomesTest SET sdate = @sdate,fileupno =@fileupno,branchname =@branchname,cname = @cname,acno = @acno,benname =@benname,currency = @currency,country =@country,accdrec =@accdrec,shdocrec =@shdocrec,pletterr =@pletterr,scontactr =@scontactr,largr =@largr,duedate =@duedate,extduedate =@extduedate,goods = @goods,invoice =@invoice,extenddatedate =@extenddatedate,extreason =@extreason,complete =@complete ,cfileupno =@cfileupno,incomplete =@incomplete,incocomment =@incocomment WHERE id = @id 
GO


