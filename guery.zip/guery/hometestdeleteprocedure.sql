USE [compliancetest]
GO

/****** Object:  StoredProcedure [dbo].[sp_delete_log]    Script Date: 3/2/2021 3:37:48 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE procedure  [dbo].[sp_delete_log]
(
	@id int,
	@employees_name varchar(255)
)

as 

insert into Delete_backUP  
select id,sdate,fileupno,branchname,cname,acno,benname,amount,currency,country,accdrec,shdocrec,
pletterr,scontactr,largr,duedate,extduedate,goods,invoice,extenddatedate,extreason,complete,
cfileupno,incomplete,incocomment,@employees_name,getdate() from HomesTest where id=@id

delete HomesTest where id=  @id
GO


