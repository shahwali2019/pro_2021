USE [compliancetest]
GO

/****** Object:  Table [dbo].[Delete_backUP]    Script Date: 3/2/2021 3:36:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Delete_backUP](
	[id] [int] NOT NULL,
	[sdate] [nvarchar](50) NULL,
	[fileupno] [nvarchar](255) NULL,
	[branchname] [nvarchar](255) NULL,
	[cname] [nvarchar](255) NULL,
	[acno] [nvarchar](255) NULL,
	[benname] [nvarchar](255) NULL,
	[amount] [nvarchar](255) NULL,
	[currency] [nvarchar](255) NULL,
	[country] [nvarchar](255) NULL,
	[accdrec] [nvarchar](255) NULL,
	[shdocrec] [nvarchar](255) NULL,
	[pletterr] [nvarchar](255) NULL,
	[scontactr] [nvarchar](255) NULL,
	[largr] [nvarchar](255) NULL,
	[duedate] [nvarchar](255) NULL,
	[extduedate] [nvarchar](255) NULL,
	[goods] [nvarchar](255) NULL,
	[invoice] [nvarchar](255) NULL,
	[extenddatedate] [nvarchar](255) NULL,
	[extreason] [nvarchar](255) NULL,
	[complete] [nvarchar](255) NULL,
	[cfileupno] [nvarchar](255) NULL,
	[incomplete] [nvarchar](255) NULL,
	[incocomment] [nvarchar](255) NULL,
	[employees_name] [nvarchar](255) NULL,
	[deleted_at] [datetime] NULL
) ON [PRIMARY]
GO


