USE [compliancetest]
GO

/****** Object:  Table [dbo].[Tableuser]    Script Date: 3/2/2021 3:37:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Tableuser](
	[username] [varchar](50) NULL,
	[password] [varchar](50) NULL,
	[usertype] [varchar](50) NULL
) ON [PRIMARY]
GO


